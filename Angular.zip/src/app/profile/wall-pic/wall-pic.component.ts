import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wall-pic',
  templateUrl: './wall-pic.component.html',
  styleUrls: ['./wall-pic.component.css']
})
export class WallPicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
