import { Component, OnInit } from '@angular/core';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Router, ActivatedRoute } from '@angular/router';

import { User } from 'src/app/interfaces/User/user';
import { Profile } from 'src/app/interfaces/Profile/profile';


@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  profile: Profile;
  error: string;
 
  _bio: string;
  _work: string;
  _education: string;
  _relationship: string;
  _currentCity: string;
  _homeTown: string;
  user:User;
  successMessage:string;

  get bio(): string {
    return this._bio;
  }
  set bio(value: string) {
    this._bio = value;
  }
  get work(): string {
    return this._work;
  }
  set work(value: string) {
    this._work = value;
  }
  get education(): string {
    return this._education;
  }
  set education(value: string) {
    this._education = value;
  }
  get relationship(): string {
    return this._relationship;
  }
  set relationship(value: string) {
    this._relationship = value;
  }
  get currentCity(): string {
    return this._currentCity;
  }
  set currentCity(value: string) {
    this._currentCity = value;
  }
  get homeTown(): string {
    return this._homeTown;
  }
  set homeTown(value: string) {
    this._homeTown = value;
  }

  constructor(private capbookService: CapbookServicesService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.user = JSON.parse(sessionStorage.getItem('loggedUser'));
  }

  acceptProfile(){
    const _profile: any = {
      profileID:this.user.profile.profileID,
      bio:this.bio,
      work: this.work,
      education: this.education,
      relationship: this.relationship,
      currentCity: this.currentCity,
      homeTown: this.homeTown, 
    }
    this.capbookService.acceptProfileDetails(_profile).subscribe(

      tempProfile =>{
        this.profile=tempProfile;
        this.successMessage="Profile has been updated Successfully";
      },
      error =>{
        this.error=error;
      });
  }

}
