import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interfaces/User/user';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Profile } from 'src/app/interfaces/Profile/profile';

@Component({
  selector: 'app-profile-about',
  templateUrl: './profile-about.component.html',
  styleUrls: ['./profile-about.component.css']
})
export class ProfileAboutComponent implements OnInit {
  user:User;
  profile:Profile;
  emailId:string;
  error: string;

  constructor(private capbookServices : CapbookServicesService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.user = JSON.parse(sessionStorage.getItem('loggedUser'));
    this.capbookServices.fetchUserDetails(this.user).subscribe(
      tempUser=>{
        this.user=tempUser;
        console.log(this.user.age);
      },
      error=>{
        this.error=error;
      });
      var profile:Profile=this.user.profile;
    this.capbookServices.fetchProfileDetails(profile).subscribe(
      tempProfile=>{
        this.profile=tempProfile;
      },
      error=>{
        this.error=error;
      });
  }
}
