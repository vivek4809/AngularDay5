import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  bio: string="Add Bio!!";
  _post: string;
  constructor() { }
  
  get post():string{
    return this._post;
  }
  set post(value:string){
    this._post=value;
  }

  ngOnInit() {
    this.bio;
  }

}
